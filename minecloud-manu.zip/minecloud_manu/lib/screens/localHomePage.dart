import 'package:flutter/material.dart';
import 'package:minecloud_tal/common/theme/text.dart';
import '../common/theme/colors.dart';
import '../widgets/upperbarW.dart';

class LocalHomePage extends StatefulWidget {
  const LocalHomePage({Key? key}) : super(key: key);

  @override
  State<LocalHomePage> createState() => _LocalHomePageState();
}

class _LocalHomePageState extends State<LocalHomePage> {
  int _selectedIndex = 0;
  final PageController _pageController = PageController();
  List<bool> pressed = [false, false, false, false, false];
  List<String> my_list = ['words', 'resorce', 'behavior', 'packs', 'videos'];
  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(gradient: darkBackgroundGradient),
        child: Scaffold(
          body: Container(
            constraints: const BoxConstraints(
              maxHeight: double.infinity,
            ),
            child: ListView(children: [
              upperbar(my_list: my_list, pressed: pressed, context: context)
            ]),
          ),
          backgroundColor: kEmptyColor,
          drawer: Drawer(),
          appBar: AppBar(
            centerTitle: true,
            backgroundColor: kTapBorderAssets,
            title: Text(
              'Local Data',
              style: poppinsMedium(),
            ),
            actions: [
              Padding(
                padding: EdgeInsets.only(right: 16.0),
                child: CircleAvatar(
                  radius: 15,
                  backgroundColor: kTapBorderAssets,
                ),
              )
            ],
            toolbarHeight: 80, //
            // bottom: Container(
            //   color: kTapBorderAssets,
            //   child: Divider()
            // ),
          ),
          bottomNavigationBar: BottomNavigationBar(
            backgroundColor: Color.fromARGB(255, 22, 54, 76),
            selectedLabelStyle: poppinsRegular(),
            unselectedLabelStyle: poppinsRegular(),
            selectedItemColor: Color.fromARGB(255, 74, 74, 181),
            currentIndex: _selectedIndex,
            onTap: (value) {
              // onTap Bottom icon
              setState() {
                _selectedIndex = value;
              }

              _pageController.jumpToPage(value);
            },
            items: const [
              BottomNavigationBarItem(
                  icon: Icon(Icons.file_download), label: 'local'),
              BottomNavigationBarItem(icon: Icon(Icons.cloud), label: 'cloud'),
            ],
          ),
        ));
  }
}
