import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../common/theme/colors.dart';
import '../common/theme/text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:minecloud_tal/common/theme/text.dart';
import 'package:minecloud_tal/screens/resetPass_page.dart';
import 'package:minecloud_tal/widgets/textFieldW.dart';
import '../common/theme/constants.dart';

Widget upperbar({
  required List<String> my_list,
  required List<bool> pressed,
  required BuildContext context,
  String selected_Cat = "",
}) {
  return Container(
    width: MediaQuery.of(context).size.width,
    child: SingleChildScrollView(
      child: Row(
          //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: my_list
              .map<Widget>((cat) => Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            pressed[my_list.indexOf(cat)] =
                                !pressed[my_list.indexOf(cat)];
                            selected_Cat = cat;
                            if (selected_Cat == my_list[0]) {}
                            if (selected_Cat == my_list[1]) {}
                            if (selected_Cat == my_list[2]) {}
                            if (selected_Cat == my_list[3]) {}
                            if (selected_Cat == my_list[4]) {}
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          primary: pressed[my_list.indexOf(cat)]
                              ? Color.fromARGB(255, 90, 111, 214)
                              : Color.fromARGB(255, 115, 115, 116),
                        ),
                        child: Text(
                          cat,
                          style: poppinsRegular(),
                        )),
                  ))
              .toList()),
    ),
  );
}

void setState(Null Function() param0) {}
