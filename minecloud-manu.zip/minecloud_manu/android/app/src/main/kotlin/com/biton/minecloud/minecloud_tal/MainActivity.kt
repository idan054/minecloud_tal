package com.biton.minecloud.minecloud_tal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
